#pragma once
class Obstacle{};