// Utility.h
#pragma once

bool checkCollision(float x1, float y1, float x2, float y2, float radius1 = 1.0f, float radius2 = 1.0f);